package org.example;

public class HotelInformation {
    String name;
    String ubication;
    public HotelInformation(String name, String ubication){
        this.name = name;
        this.ubication = ubication;
    }
}
