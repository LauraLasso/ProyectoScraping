package org.example;

public class DMLTranslator {
    private static final String INSERT_HOTEL =
            "INSERT INTO Hotel(name, ubication) VALUES ('%s', '%s')";
    private static final String INSERT_RATINGS =
            "INSERT INTO Ratings(category, puntuation) VALUES ('%s', '%s')";
    private static final String INSERT_SERVICES =
            "INSERT INTO Services(type, information) VALUES ('%s', '%s')";
    private static final String INSERT_OPINIONS =
            "INSERT INTO Opinions(name, country, puntuation, comment, positive, negative, days) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')";

    public static String insertHotel(HotelInformation hotel){
        return String.format(INSERT_HOTEL,
                hotel.name,
                hotel.ubication);
    }

    public static String insertRatings(Ratings rating){
        return String.format(INSERT_RATINGS,
                rating.category,
                rating.puntuation);
    }

    public static String insertServices(Services service) {
        return String.format(INSERT_SERVICES,
                service.typeService,
                service.information);
    }

    public static String insertOpinions(Opinions opinion){
        return String.format(INSERT_OPINIONS,
                opinion.name,
                opinion.country,
                opinion.puntuation,
                opinion.comment,
                opinion.positiveComment,
                opinion.negativeComment,
                opinion.days);
    }
}
