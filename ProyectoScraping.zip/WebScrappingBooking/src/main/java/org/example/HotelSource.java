package org.example;

import java.util.List;

public interface HotelSource {
    List<HotelInformation> Hotel() throws Exception;
    List<Services> totalServices() throws Exception;
    List<Ratings> totalRatings() throws Exception;
    List<Opinions> totalOpinions() throws Exception;
}
