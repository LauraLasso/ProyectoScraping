package org.example;

public class Main {
    public static void main(String[] args) throws Exception {
        new Controller(new Scrapping(), new SqliteHotelDatabase()).start();
    }
}