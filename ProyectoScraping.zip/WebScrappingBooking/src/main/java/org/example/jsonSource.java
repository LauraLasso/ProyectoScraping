package org.example;

public interface jsonSource {
    public String render(Object model);
}
