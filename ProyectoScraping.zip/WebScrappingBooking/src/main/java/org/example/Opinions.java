package org.example;

public class Opinions {
    String name;
    String country;
    String puntuation;
    String comment;
    public String positiveComment;
    public String negativeComment;
    public String days;

    public Opinions(String name, String country, String puntuation, String comment, String positiveComment, String negativeComment, String days){
        this.name = name;
        this.country = country;
        this.puntuation = puntuation;
        this.comment = comment;
        this.positiveComment = positiveComment;
        this.negativeComment=negativeComment;
        this.days = days;
    }

    public String getName() {
        return name;
    }

    public String getCountry() {
        return country;
    }

    public String getPuntuation() {
        return puntuation;
    }

    public String getComment() {
        return comment;
    }

    public String getPositiveComment() {
        return positiveComment;
    }

    public String getNegativeComment() {
        return negativeComment;
    }
}
