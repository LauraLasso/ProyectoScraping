package org.example;

public class Ratings {
    String category;
    String puntuation;
    public Ratings(String category, String puntuation){
        this.category = category;
        this.puntuation = puntuation;
    }
}
