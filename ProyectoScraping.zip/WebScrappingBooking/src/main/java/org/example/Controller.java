package org.example;

import java.util.List;

public class Controller {

    HotelSource source;
    HotelDatabase hotelDatabase;


    public Controller(HotelSource source, HotelDatabase hotelDatabase) throws Exception {
        this.source = source;
        this.hotelDatabase = hotelDatabase;
    }

    public void start() throws Exception {
        List<HotelInformation> hotels = source.Hotel();
        List<Ratings> ratings = source.totalRatings();
        List<Services> services = source.totalServices();
        List<Opinions> opinions = source.totalOpinions();

        for (HotelInformation hotel: hotels){
            hotelDatabase.add(hotel);
        }
        for (Ratings rating: ratings){
            hotelDatabase.add(rating);
        }
        for (Services service: services){
            hotelDatabase.add(service);
        }
        for (Opinions opinion: opinions){
            hotelDatabase.add(opinion);
        }
        new HotelAPI().start();
    }
}
