package org.example;

import com.google.gson.JsonArray;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.*;

public class Scrapping implements HotelSource{

    final Document PagHTML = Scrapping.getHTML("https://www.booking.com/hotel/es/riu-buenavista-all-inclusive.es.html?aid=1181029&label=msn-VPMTfA4460dKWeMSTxnoxg-80539326887552%3Atidat-2332339040747308%3Aloc-170%3Aneo%3Amtb%3Alp3191%3Adec%3Aqshotel%20riu%20buenavista%20booking%20opiniones&sid=c6f39b868d44d5256d62cb07ab2e04f7&dest_id=-369166;dest_type=city;dist=0;group_adults=2;group_children=0;hapos=1;hpos=1;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;srepoch=1669031226;srpvid=5d1152dcf7f6016f;type=total;ucfs=1&#tab-main");
    final Document PagHTMLOpinions = Scrapping.getHTML("https://www.booking.com/reviews/es/hotel/riu-buenavista-all-inclusive.es.html#tab-main");
    public static Document getHTML(String url){
        Document html = null;
        try{
            html = Jsoup.connect(url).userAgent("Mozilla/5.0").timeout(100000).get();
        }
        catch (Exception e){
            System.out.println("Error2");
        }
        return html;
    }

    @Override
    public List<HotelInformation> Hotel() {
        List<HotelInformation> hotel = new ArrayList<>();
        try {
            String ubication = PagHTML.select("span.hp_address_subtitle.js-hp_address_subtitle.jq_tooltip").text();
            String name = PagHTML.select("h2.d2fee87262.pp-header__title").text();
            hotel.add(new HotelInformation(name, ubication));
        }catch (Exception e){
            System.out.println("Error1");
        }
        return hotel;
    }


    @Override
    public List<Services> totalServices() {
        List<Services> services = new ArrayList<>();
        Elements servicios = PagHTML.select("div.bui-spacer--large");

        try{
            for(Element servicio : servicios){
                List<String> DetailsResult = new ArrayList<>();
                String campo = servicio.select("div.bui-title.bui-title--strong_1.bui-spacer--medium.hotel-facilities-group__title").text();
                Elements details = servicio.select("div.bui-list__body");
                for(Element detail : details){
                    String detail1 = detail.text();
                    DetailsResult.add(detail1);
                }
                String DetailsString = String.join(", ", DetailsResult);
                services.add(new Services(campo, DetailsString));
            }
        }catch (Exception e){
            System.out.println("Error1");
        }
        return services;
    }

    @Override
    public List<Ratings> totalRatings() {
        List<Ratings> ratings = new ArrayList<>();
        Map<String, String> hm = new HashMap<String, String>();
        try {
            Elements categories = PagHTML.select("div.a1b3f50dcd.b2fe1a41c3.a1f3ecff04.e187349485.d19ba76520");
            for (Element category : categories) {
                String nameCategory = category.select("span.d6d4671780").text();
                String puntuation = category.select("div.ee746850b6.b8eef6afe1").text();
                //ratings.add(new Ratings(nameCategory, puntuation));
                hm.put(nameCategory, puntuation);

            }
            Set<String> keys = hm.keySet();
            for(String key: keys){
                String value = hm.get(key);
                ratings.add(new Ratings(key, value));
            }

        }catch (Exception e){
            System.out.println("Error1");
        }
        return ratings;
    }

    @Override
    public List<Opinions> totalOpinions() {
        List<Opinions> totalOpinions = new ArrayList<>();
        Elements opinions = PagHTMLOpinions.select("li.review_item.clearfix");

        for (Element opinion:opinions){
            JsonArray name = new JsonArray();
            JsonArray country = new JsonArray();
            Elements clients = opinion.select("div.review_item_reviewer");

            for (Element client:clients){
                String n = client.getElementsByClass("reviewer_name").text();
                String c = client.getElementsByClass("reviewer_country").text();
                name.add(n);
                country.add(c);
            }

            JsonArray allPunctuation = new JsonArray();
            JsonArray review = new JsonArray();
            Elements punctuations = opinion.select("div.review_item_review_container.lang_ltr");
            for (Element punctuation : punctuations) {
                String p1 = punctuation.getElementsByClass("review-score-badge").text();
                String p2 = punctuation.getElementsByClass("review_item_header_content").text();
                allPunctuation.add(p1);
                review.add(p2);
            }

            JsonArray positive = new JsonArray();
            JsonArray negative = new JsonArray();
            JsonArray days = new JsonArray();

            Elements annotations = opinion.select("div.review_item_review_content");
            for (Element annotation : annotations) {
                String p = annotation.getElementsByClass("review_pos").text();
                String n = annotation.getElementsByClass("review_neg").text();
                String d = annotation.getElementsByClass("review_staydate").text();
                positive.add(p);
                negative.add(n);
                days.add(d);
            }
            System.out.println(totalOpinions);
            totalOpinions.add(new Opinions(name.toString().replaceAll("[\"\\[\\]]",""),
                    country.toString().replaceAll("[\"\\[\\]]",""),
                    allPunctuation.toString().replaceAll("[\"\\[\\]]",""),
                    review.toString().replaceAll("[\"\\u201C\\u201D\\[\\]]",""),
                    positive.toString().replaceAll("[\"\\[\\]]",""),
                    negative.toString().replaceAll("[\"\\[\\]]",""),
                    days.toString().replaceAll("[\"\\[\\]]","")));
        }
        System.out.println(totalOpinions);
        return totalOpinions;
    }

}
