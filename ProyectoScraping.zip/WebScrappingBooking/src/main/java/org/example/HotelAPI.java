package org.example;

import spark.Request;
import spark.Response;

import java.util.List;

import static spark.Spark.*;

//http://localhost:4567/hotels/:riu-buenavista-all-inclusive
public class HotelAPI {
    public void startServer() {
        port(4567);
        staticFiles.location("/public");
    }

    private static Scrapping scrapping = new Scrapping();
    private jsonSource toJson = new JsonTransformer();

    public void start(){
        get("/hotels/:name ", this::hotel);
        get("/hotels/:name/ratings", this::ratings);
        get("/hotels/:name/comments", this::comments);
        get("/hotels/:name/services", this::services);
    }

    private String services(Request request, Response response) throws Exception {
        response.type("application/json");
        List<HotelInformation> locations = scrapping.Hotel();
        return toJson.render(locations);
    }

    private String comments(Request request, Response response) throws Exception {
        response.type("application/json");
        List<Opinions> comments = scrapping.totalOpinions();
        return toJson.render(comments);
    }

    private String ratings(Request request, Response response) throws Exception {
        response.type("application/json");
        List<Ratings> assessments = scrapping.totalRatings();
        return toJson.render(assessments);
    }

    private String hotel(Request request, Response response) throws Exception {
        response.type("application/json");
        List<HotelInformation> locations = scrapping.Hotel();
        return toJson.render(locations);
    }

}
