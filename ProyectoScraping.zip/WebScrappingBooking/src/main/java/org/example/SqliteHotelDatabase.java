package org.example;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SqliteHotelDatabase implements HotelDatabase{

    private final Connection connection;

    public SqliteHotelDatabase() throws SQLException {
        String url ="jdbc:sqlite:HotelBooking.db";
        connection = DriverManager.getConnection(url);
        initDatabase();
    }

    private static final String INIT =
            "CREATE TABLE IF NOT EXISTS Hotel (" +
                    "name TEXT, " +
                    "ubication TEXT);";

    private static final String INIT2 =
            "CREATE TABLE IF NOT EXISTS Ratings (" +
                    "category TEXT, " +
                    "puntuation TEXT);";

    private static final String INIT3 =
            "CREATE TABLE IF NOT EXISTS Services (" +
                    "type TEXT, " +
                    "information TEXT);";

    private static final String INIT4 =
            "CREATE TABLE IF NOT EXISTS Opinions (" +
                    "name TEXT, " +
                    "country TEXT, " +
                    "puntuation TEXT, " +
                    "comment TEXT, " +
                    "positive TEXT, " +
                    "negative TEXT, " +
                    "days TEXT);";



    private void initDatabase() throws SQLException{
        connection.createStatement().execute(INIT);
        connection.createStatement().execute(INIT2);
        connection.createStatement().execute(INIT3);
        connection.createStatement().execute(INIT4);
    }

    @Override
    public void add(HotelInformation hotel) throws SQLException {
        try{
            connection.createStatement().execute(DMLTranslator.insertHotel(hotel));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void add(Ratings ratings) throws SQLException {
        try{
            connection.createStatement().execute(DMLTranslator.insertRatings(ratings));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void add(Services services) throws SQLException {
        try{
            connection.createStatement().execute(DMLTranslator.insertServices(services));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void add(Opinions opinions) throws SQLException {
        try{
            connection.createStatement().execute(DMLTranslator.insertOpinions(opinions));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

}
