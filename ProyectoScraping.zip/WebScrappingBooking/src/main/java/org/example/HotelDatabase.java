package org.example;

public interface HotelDatabase {
    void add(HotelInformation hotelInformation) throws Exception;
    void add(Opinions Opinions) throws Exception;
    void add(Ratings ratings) throws Exception;
    void add(Services services) throws Exception;
}
