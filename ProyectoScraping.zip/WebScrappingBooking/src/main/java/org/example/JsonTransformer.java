package org.example;

import com.google.gson.Gson;

public class JsonTransformer implements jsonSource{
    private Gson gson = new Gson();
    public String render(Object model) {
        return gson.toJson(model);
    }
}
