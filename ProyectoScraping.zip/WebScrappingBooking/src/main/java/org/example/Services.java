package org.example;

import java.util.List;

public class Services {
    String typeService;
    String information;
    public Services(String typeService, String information){
        this.typeService = typeService;
        this.information = information;
    }
}
